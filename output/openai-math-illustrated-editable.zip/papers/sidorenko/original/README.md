# [A counterexample to Sidorenko's conjecture](paper.pdf)

**Author:** OpenAI  
**Date:** September 23, 2026

## Citation

```bibtex
@misc{OAI:A-counterexample-to-Sidorenkos-conjecture-September-23-2026,
  author = {{OpenAI}},
  title = {{A counterexample to Sidorenko's conjecture}},
  howpublished = {OpenAI Math Release preprint
                  \href{https://github.com/openai/math/blob/main/preprints/A-counterexample-to-Sidorenkos-conjecture-September-23-2026/paper.pdf}{OAI:A-counterexample-to-Sidorenkos-conjecture-September-23-2026}},
  year = {2026}
}
```

